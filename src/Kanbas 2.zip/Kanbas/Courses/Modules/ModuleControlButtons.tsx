import { IoEllipsisVertical } from "react-icons/io5";
import { FaTrash } from "react-icons/fa";
import { FaPencil } from "react-icons/fa6";

import { BsPlusLg } from "react-icons/bs";
import GreenCheckmark from "./GreenCheckmark";

export default function ModuleControlButtons({ moduleId, deleteModule, editModule }: {
  moduleId: string; deleteModule: (moduleId: string) => void;
  editModule: (moduleId: string) => void }) {

  return (
    <div className="d-flex align-items-center float-end p-2">
       <FaPencil onClick={() => editModule(moduleId)} className="text-primary me-3" />

     <FaTrash className="text-danger me-2 mb-1" onClick={() => deleteModule(moduleId)}/>
     

      <GreenCheckmark />
      <BsPlusLg className="mx-1" />
      <IoEllipsisVertical className="fs-4" />
    </div>
  );
}

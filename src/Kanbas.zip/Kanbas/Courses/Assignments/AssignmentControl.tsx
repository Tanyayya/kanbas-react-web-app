import { FaPlus } from "react-icons/fa6";
import { useNavigate } from "react-router-dom";

export default function AssignmentControls() {
  const navigate = useNavigate();

  const handleAddAssignment = () => {
    navigate(`/new`);
  };

  return (
    <div id="wd-modules-controls" className="text-nowrap">
      <button
        id="wd-add-module-btn"
        className="btn btn-md btn-danger float-end"
        onClick={handleAddAssignment}
      >
        <FaPlus className="position-relative me-2" style={{ bottom: "1px" }} />
        Assignment
      </button>
      <button
        id="wd-add-module-btn"
        className="btn btn-md btn-secondary me-1 float-end"
      >
        <FaPlus className="position-relative me-2" style={{ bottom: "1px" }} />
        Group
      </button>
    </div>
  );
}

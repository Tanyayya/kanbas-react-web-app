import { createSlice } from "@reduxjs/toolkit";
import { assignments } from "../../Database"; // Import the assignments from your Database module

const initialState = {
  assignments: assignments,
};

const assignmentsSlice = createSlice({
  name: "assignments",
  initialState,
  reducers: {
    addAssignment: (state, { payload: assignment }) => {
      const newAssignment: any = {
        _id: new Date().getTime().toString(),
        title: assignment.title,
        description: assignment.description,
        dueDate: assignment.dueDate,
        availableDate: assignment.availableDate,
        points: assignment.points,
        group: assignment.group,
        submissionType: assignment.submissionType,
      };
      state.assignments=[...state.assignments, newAssignment] as any;
    },
    deleteAssignment: (state, { payload: assignmentId }) => {
      state.assignments = state.assignments.filter(
        (a: any) => a._id !== assignmentId
      );
    },
    updateAssignment: (state, { payload: assignment }) => {
      state.assignments = state.assignments.map((a: any) =>
        a._id === assignment._id ? assignment : a
      );
    },
    // You can add additional functions as needed
    editModule: (state, { payload: assignmentId }) => {
      state.assignments = state.assignments.map((m: any) =>
        m._id === assignmentId ? { ...m, editing: true } : m
    ) as any;
},
  },
});

export const { addAssignment, deleteAssignment, updateAssignment } = assignmentsSlice.actions;

export default assignmentsSlice.reducer;
